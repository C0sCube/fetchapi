import json
from pathlib import Path

from docling.document_converter import DocumentConverter
from docling.datamodel.base_models import InputFormat
from docling.datamodel.pipeline_options import (PdfPipelineOptions, TableStructureOptions)
from docling.document_converter import PdfFormatOption

from pathlib import Path
import os
import time as ts

folder_path = r"D:\Developers\Kaustubh\doctest\CFD_10_COMPANIES"
fol_path = Path(folder_path)
output_dir = r"cfd_output"

output_dir = Path(output_dir)
output_dir.mkdir(parents=True, exist_ok=True)


def convert_pdf(pdf_path, output_dir, do_ocr = True):

    pipeline_options = PdfPipelineOptions()
    pipeline_options.do_ocr = do_ocr
    pipeline_options.table_structure_options = TableStructureOptions(do_cell_matching=True)

    #format:opts

    converter = DocumentConverter(
        format_options={
            InputFormat.PDF: PdfFormatOption(
                pipeline_options=pipeline_options
            )
        }
    )


    name = Path(pdf_path).stem

    print(f"Converting PDF... Do OCR: {do_ocr}")
    result = converter.convert(pdf_path)

    doc = result.document
    md_path = output_dir / f"document_{name}.md"

    with open(md_path, "w", encoding="utf-8") as f:
        f.write(doc.export_to_markdown())
        
    json_path = output_dir / f"document_{name}.json"

    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(
            doc.export_to_dict(),
            f,
            indent=2,
            ensure_ascii=False
        )

    print(f"Markdown : {md_path}")
    print(f"JSON      : {json_path}")




if __name__ == "__main__":

    for file in os.listdir(folder_path):

        fpth = os.path.join(folder_path, file)
        st_dt = ts.perf_counter()
        convert_pdf(fpth, output_dir, do_ocr = False)
        en_dt = ts.perf_counter()
        print(f"{file}: TIME TAKEN: {en_dt - st_dt}")
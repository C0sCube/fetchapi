@echo off
set HF_HOME=E:\huggingface
set PADDLEX_HOME=E:\paddlex
call C:\Users\rando\miniconda3\Scripts\activate.bat E:\conda-envs\paddle-vl
cmd /k
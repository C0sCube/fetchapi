from pathlib import Path
import json, time
import pandas as pd
from paddleocr import PaddleOCRVL  # type: ignore

BATCH_DIR = Path(r"C:\Users\rando\Office Projects\rep_fetchapi\pdf_batch")
OUT = Path("ocr_results")
OUT.mkdir(exist_ok=True)

print("Loading PaddleOCR-VL...")
start = time.perf_counter()
pipeline = PaddleOCRVL()
print(f"Loaded in {time.perf_counter() - start:.2f}s")

batch_files = sorted(BATCH_DIR.glob("_batch_*.pdf"))

print(f"Batch PDFs: {len(batch_files)}")

metrics = []
total_start = time.perf_counter()

for batch_id, batch_pdf in enumerate(batch_files, 1):

    print(f"\nBatch {batch_id}: {batch_pdf.name}")

    start = time.perf_counter()
    results = pipeline.predict(str(batch_pdf))

    pages = []

    for page_num, result in enumerate(results, 1):

        blocks = [
            {"label": item.label, "bbox": list(item.bbox), "content": item.content}
            for item in result["parsing_res_list"]
        ]

        pages.append(
            {
                "page": page_num,
                "blocks": blocks,
                "markdown": result.markdown["markdown_texts"],
            }
        )

    elapsed = time.perf_counter() - start

    output = {"batch": batch_pdf.name, "pages": pages}

    with open(OUT / f"{batch_pdf.stem}.json", "w", encoding="utf-8") as f:
        json.dump(output, f, indent=2, ensure_ascii=False)

    metrics.append(
        {
            "batch_id": batch_id,
            "batch_pdf": batch_pdf.name,
            "pages": len(pages),
            "time_sec": round(elapsed, 3),
            "pages_per_sec": round(len(pages) / elapsed, 3),
        }
    )

    print(f"Pages: {len(pages)}")
    print(f"Time: {elapsed:.2f}s")
    print(f"Pages/sec: {len(pages) / elapsed:.2f}")

total_time = time.perf_counter() - total_start

pd.DataFrame(metrics).to_excel(OUT / "batch_metrics.xlsx", index=False)

print(f"\nTotal time: {total_time:.2f}s")
print("Done.")

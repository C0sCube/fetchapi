@echo off
call C:\Users\rando\miniconda3\Scripts\activate.bat E:\conda-envs\docling-env
cd /d E:\conda-envs
cmd /k